
# Módulo Prestadores de Serviços

Novo módulo completo para gerenciar empresas terceirizadas, integrado ao fluxo de manutenções existente.

## 1. Banco de dados (migration única)

Novo bucket de storage: `prestadores` (privado, mesmas RLS de leitura autenticada).

Novas tabelas em `public`:

**`prestadores`** — cadastro das empresas
- nome_empresa, responsavel, cnpj, telefone, whatsapp, email
- categoria (text — Elevadores, Portões, Elétrica, …, Outros)
- status ('ativa' | 'em_avaliacao' | 'inativa'), observacoes
- logo_path (storage), documentos (jsonb — contratos permanentes)
- created_by, timestamps

**`prestador_avaliacoes`** — avaliações por serviço
- prestador_id, manutencao_id (FK opcional)
- qualidade, organizacao, prazo, atendimento, limpeza (int 0-5)
- nota_geral (numeric, média), comentario
- avaliado_por, created_at

**Alterações em `manutencoes`** (colunas nullable, sem quebrar dados atuais):
- `tipo_servico` text default 'interno' ('interno' | 'terceirizado')
- `prestador_id` uuid FK → prestadores
- `prestador_responsavel` text
- `funcionario_acompanhante` text
- `data_solicitacao`, `data_agendada` timestamptz
- `valor_servico` numeric, `garantia_dias` int
- `orcamentos`, `notas_fiscais`, `arts`, `laudos`, `relatorios`, `contratos` jsonb default `[]` (mesmo shape de anexos existentes)
- `timeline_events` jsonb default `[]` — array de `{evento, at, by}` (Solicitado, Empresa acionada, Agendado, Chegou, Iniciado, Fotos, Concluído, Conferido)

Grants padrão + RLS: autenticados leem/escrevem; conselheiro só leitura (mesmo padrão dos módulos atuais). Trigger `updated_at`.

## 2. Server functions / Data layer

Novo `src/lib/prestadores.ts`:
- Tipos `Prestador`, `PrestadorAvaliacao`, `CATEGORIAS_PRESTADOR`, `STATUS_PRESTADOR`
- Helpers: `listPrestadores`, `getPrestador(id)`, `createPrestador`, `updatePrestador`, `deletePrestador`
- `getPrestadorHistorico(id)` — agrega manutenções: total, último atendimento, tempo médio (inicio→conclusão), avaliação média
- `criarAvaliacao`, `listAvaliacoes(prestadorId)`

Todas as chamadas via `supabase` client (mesmo padrão do `manutencoes.ts`), respeitando RLS.

## 3. Rotas novas (TanStack file-based)

- `src/routes/_authenticated/prestadores.tsx` — layout `<Outlet />`
- `src/routes/_authenticated/prestadores.index.tsx` — lista + filtros (categoria, status, busca), dashboard resumido no topo (KPIs: ativas, serviços em andamento, aguardando orçamento, concluídos no mês, top 3 melhor avaliadas)
- `src/routes/_authenticated/prestadores.novo.tsx` — formulário criar
- `src/routes/_authenticated/prestadores.$id.tsx` — perfil: header (logo, nome, status, contato) + tabs: Informações, Histórico (lista de OS terceirizadas), Documentos (contratos), Avaliações
- `src/routes/_authenticated/prestadores.$id.editar.tsx` — editar
- `src/routes/_authenticated/prestadores.relatorios.tsx` — relatórios filtráveis (empresa/categoria/período/status/valor/garantia)

## 4. Componentes

- `src/components/PrestadorForm.tsx` — form cadastro/edição (usa `AnexoUploader` para logo e contratos)
- `src/components/PrestadorCard.tsx` — card resumo com badge de status colorido (🟢🟡🔴) e categoria
- `src/components/PrestadorSelect.tsx` — combobox usado no `ManutencaoForm`
- `src/components/TimelineServico.tsx` — linha do tempo vertical dos `timeline_events` com ícones (📅📞📆🚚🔧📸✅✔)
- `src/components/AvaliacaoStars.tsx` — 5 estrelas por critério + nota geral calculada
- `src/components/AvaliacaoForm.tsx` — modal para avaliar após conclusão
- `src/components/TipoServicoBadge.tsx` — etiqueta 👷 Interno / 🏢 Terceirizada

## 5. Integração com Manutenções (mínima, só UI + persistência)

Em `ManutencaoForm.tsx`:
- Novo bloco no topo: RadioGroup "Tipo do Serviço" (Interno / Terceirizada)
- Se Terceirizada: `PrestadorSelect`, responsável (auto do prestador, editável), funcionário acompanhante, data solicitação/agendada, valor, garantia (dias)
- Nova aba/seção de anexos: Orçamento, Nota Fiscal, ART, Laudos, Relatórios, Contrato (além dos existentes Antes/Depois/Fotos/Documentos)
- Timeline: botões para registrar eventos (append em `timeline_events`) — apenas visível em edição

Em `manutencoes.$id.tsx` e `manutencoes.tsx` (lista):
- Exibir `TipoServicoBadge` ao lado do número do chamado
- Se terceirizada: mostrar nome da empresa, `TimelineServico`, botão "Avaliar" (quando status = Concluído e ainda não avaliada)

## 6. Alertas

Estender `AlertsBar.tsx` para incluir:
- 🔴 Garantia vence em ≤5 dias (calc: `data_conclusao + garantia_dias`)
- 🟡 Serviço terceirizado com `data_agendada` no passado sem `data_inicio`
- 📄 Terceirizada sem orçamento anexado

## 7. Menu lateral

Em `src/routes/_authenticated/route.tsx`, adicionar ao `NAV`:
```
{ to: "/prestadores", label: "Prestadores", icon: Building2 }
```
(ícone `Building2` do lucide-react)

## Notas técnicas

- Zero alteração em `src/integrations/supabase/*` (auto-gen).
- Reuso total de `AnexoUploader` + bucket novo `prestadores` (logo/contrato permanente) e bucket `manutencoes` para anexos ligados à OS.
- Todas as novas colunas em `manutencoes` são nullable → dados existentes não quebram.
- Conselheiro (read-only) continua não podendo criar/editar prestadores nem avaliar.
- Sem mudança em rotas existentes, sem tocar em `src/lib/manutencoes.ts` além de possivelmente adicionar campos aos tipos (só additive).
